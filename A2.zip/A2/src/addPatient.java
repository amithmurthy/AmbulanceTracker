import java.io.IOException;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class addPatient  extends AmbulanceTrackerApp{
	
	public static void save(ActionEvent e){
		
	}
	
	
	
	public static void main(String[] args){
		
	}
}
